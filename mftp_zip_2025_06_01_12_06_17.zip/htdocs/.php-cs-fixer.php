<?php

$config = new \PhpCsFixer\Config();
$config->setRules([
    'braces' => false,
]);

return $config;
